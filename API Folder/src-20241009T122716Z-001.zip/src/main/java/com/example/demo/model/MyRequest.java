package com.example.demo.model;

public class MyRequest {
    private String param1;
    private int param2;

    // Getters and Setters
    public String getParam1() {
        return param1;
    }

    public void setParam1(String param1) {
        this.param1 = param1;
    }

    public int getParam2() {
        return param2;
    }

    public void setParam2(int param2) {
        this.param2 = param2;
    }
}
